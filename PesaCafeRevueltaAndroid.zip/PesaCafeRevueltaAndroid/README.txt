PESA CAFÉ REVUELTA — proyecto Android

IMPORTANTE:
Este archivo ZIP contiene el PROYECTO FUENTE para compilar una APK.
No es una APK ya compilada.

Cómo compilar:
1. Instala Android Studio en una computadora.
2. Abre Android Studio y selecciona "Open".
3. Elige la carpeta PesaCafeRevuelta que extrajiste de este ZIP.
4. Acepta la instalación de los componentes SDK que Android Studio solicite.
5. En el menú Build, selecciona Build Bundle(s) / APK(s) > Build APK(s).
6. Cuando termine, Android Studio mostrará la ubicación del archivo APK.

La aplicación incluye el HTML sin conexión en app/src/main/assets/index.html.
Los registros usan almacenamiento local del WebView. Exporta copias de seguridad
con frecuencia. Antes de distribuirla, prueba el guardado y las descargas CSV/JSON
en el teléfono objetivo.
